# README #

This README would normally document whatever steps are necessary to get your application up and running.

### Demo App screens flow detail and how it's work ###

First screen loads the city data as you mentioned in documents (Min 3 and Max7) user can add comma separated.  When user enter valid cities then “Get Cities Weather” button gets enable and list get updated information from api. 
Second button “Forecast Weather” will open the second screen which is developed in Objective C. This screen will get the list of forecast data as per user current location.

### What is this repository for? ###

* Quick summary
* Version
* [Learn Markdown](https://bitbucket.org/tutorials/markdowndemo)

### How do I get set up? ###

* Summary of set up
* Configuration
* Dependencies
* Database configuration
* How to run tests
* Deployment instructions

### Contribution guidelines ###

* Writing tests
* Code review
* Other guidelines

### Who do I talk to? ###

* Repo owner or admin
* Other community or team contact