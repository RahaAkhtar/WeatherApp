//
//  ForecastCellTableViewCell.h
//  OpenWeatherApp
//
//  Created by Muhammad  Akhtar on 7/4/20.
//  Copyright © 2020 Akhtar. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface ForecastCellTableViewCell : UITableViewCell

@end

NS_ASSUME_NONNULL_END
